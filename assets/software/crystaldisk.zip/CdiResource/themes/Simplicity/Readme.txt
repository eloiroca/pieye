Simplicity Six - Crystal Disk Info v6 Theme

Designed by RejZoR
http://www.rejzor.tk
rejzor[at]gmail.com

Theme based on "classic" theme with a touch of simplicity :)